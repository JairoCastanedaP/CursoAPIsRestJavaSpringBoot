package com.banca.digital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBancaDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
